import type { StoryWithSuggestions } from "@/types"

export function storyToJiraRow(story: StoryWithSuggestions): Record<string, string> {
  const summary = `${story.asA}: ${story.iWant}`

  const descriptionParts = [`As a ${story.asA}`, `I want ${story.iWant}`, `So that ${story.soThat}`, ""]

  if (story.risks.length > 0) {
    descriptionParts.push("**Risks:**")
    story.risks.forEach((risk) => descriptionParts.push(`- ${risk}`))
    descriptionParts.push("")
  }

  if (story.actionItems.length > 0) {
    descriptionParts.push("**Action Items:**")
    story.actionItems.forEach((item) => descriptionParts.push(`- ${item}`))
    descriptionParts.push("")
  }

  if (story.evidence.length > 0) {
    descriptionParts.push("**Evidence:**")
    story.evidence.forEach((ev) => {
      descriptionParts.push(`[${ev.timestamp}] ${ev.speaker}: "${ev.quote}"`)
    })
  }

  const description = descriptionParts.join("\n")

  return {
    Summary: summary,
    Description: description,
    Assignee: story.assignedTo || "",
    Labels: story.labels.join(", "),
    "Due Date": story.dueDate,
    Estimate: String(story.estimate),
  }
}

export function downloadCSV(stories: StoryWithSuggestions[], sprintId: string) {
  const headers = ["Summary", "Description", "Assignee", "Labels", "Due Date", "Estimate"]
  const rows = stories.map(storyToJiraRow)

  const csvContent = [
    headers.join(","),
    ...rows.map((row) =>
      headers
        .map((header) => {
          const value = row[header] || ""
          // Escape quotes and wrap in quotes if contains comma, newline, or quote
          if (value.includes(",") || value.includes("\n") || value.includes('"')) {
            return `"${value.replace(/"/g, '""')}"`
          }
          return value
        })
        .join(","),
    ),
  ].join("\n")

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)

  link.setAttribute("href", url)
  link.setAttribute("download", `sprint_export_${sprintId}.csv`)
  link.style.visibility = "hidden"
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export const exportToCSV = downloadCSV
