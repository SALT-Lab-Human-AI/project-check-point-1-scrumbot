"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Upload, FileText, Sparkles, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { WeightTuner } from "@/components/weight-tuner"
import { useStore } from "@/lib/store"
import { parseTranscript, detectFormat } from "@/lib/parseTranscript"
import { DEMO_KB, DEMO_TRANSCRIPT } from "@/lib/fixtures"

export default function LandingPage() {
  const router = useRouter()
  const { setTranscript, setTeamKB, teamKB, setCurrentStep } = useStore()

  const [pastedText, setPastedText] = useState("")
  const [isDragging, setIsDragging] = useState(false)

  const handleFileUpload = async (file: File) => {
    try {
      const content = await file.text()
      const format = detectFormat(file.name)
      const segments = parseTranscript(content, format)

      if (segments.length === 0) {
        alert("No transcript segments found. Please check the file format.")
        return
      }

      setTranscript(segments)
    } catch (error) {
      console.error("[v0] Error parsing file:", error)
      alert("Failed to parse transcript file")
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const file = e.dataTransfer.files[0]
    if (file) {
      handleFileUpload(file)
    }
  }

  const handlePaste = () => {
    if (!pastedText.trim()) {
      alert("Please paste some transcript text")
      return
    }

    const segments = parseTranscript(pastedText, "txt")
    setTranscript(segments)
  }

  const loadDemoData = () => {
    setTranscript(DEMO_TRANSCRIPT)
    setTeamKB(DEMO_KB)
  }

  const handleProcess = () => {
    const transcript = useStore.getState().transcript

    if (transcript.length === 0) {
      alert("Please upload or paste a transcript first")
      return
    }

    if (!teamKB) {
      alert("Please load demo data or wait for team data to be loaded")
      return
    }

    setCurrentStep("loading")
    router.push("/loading")
  }

  const displayTeam = teamKB?.members || DEMO_KB.members

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold mb-3 text-balance">Sprint Planning Assistant</h1>
        <p className="text-lg text-muted-foreground text-pretty">
          Upload meeting transcripts and let AI suggest optimal story owners
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* File Upload */}
          <Card className="p-6 rounded-2xl">
            <Label className="text-lg font-semibold mb-4 block">Transcript Upload</Label>

            <div
              onDragOver={(e) => {
                e.preventDefault()
                setIsDragging(true)
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
                isDragging ? "border-primary bg-primary/5" : "border-border"
              }`}
            >
              <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-sm text-muted-foreground mb-4">
                Drag and drop your transcript file here, or click to browse
              </p>
              <input
                type="file"
                accept=".srt,.vtt,.txt"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) handleFileUpload(file)
                }}
                className="hidden"
                id="file-upload"
              />
              <Button asChild variant="outline">
                <label htmlFor="file-upload" className="cursor-pointer">
                  <FileText className="h-4 w-4 mr-2" />
                  Choose File
                </label>
              </Button>
              <p className="text-xs text-muted-foreground mt-2">Supports .srt, .vtt, and .txt formats</p>
            </div>
          </Card>

          {/* Paste Transcript */}
          <Card className="p-6 rounded-2xl">
            <Label htmlFor="paste-transcript" className="text-lg font-semibold mb-4 block">
              Or Paste Transcript
            </Label>
            <Textarea
              id="paste-transcript"
              placeholder="Paste your transcript here..."
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              className="min-h-[200px] font-mono text-sm"
            />
            <Button onClick={handlePaste} className="mt-4" variant="secondary">
              Parse Pasted Text
            </Button>
          </Card>

          <Card className="p-6 rounded-2xl">
            <Label className="text-lg font-semibold mb-4 block">Team Members</Label>
            <div className="space-y-3">
              {displayTeam.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{member.name}</p>
                      <p className="text-sm text-muted-foreground">{member.role}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{member.capacity.hoursPerSprint}h</p>
                    <p className="text-xs text-muted-foreground">capacity</p>
                  </div>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-4 text-center">
              Team data will be loaded from database in production
            </p>
          </Card>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          <WeightTuner />

          <Card className="p-6 rounded-2xl">
            <Button onClick={loadDemoData} variant="outline" className="w-full bg-transparent" size="lg">
              <Sparkles className="h-4 w-4 mr-2" />
              Load Demo Data
            </Button>
            <p className="text-xs text-muted-foreground mt-3 text-center">
              Try ScrumBot with sample transcript and team data
            </p>
          </Card>

          <Button onClick={handleProcess} size="lg" className="w-full">
            Process Transcript
          </Button>
        </div>
      </div>
    </div>
  )
}
